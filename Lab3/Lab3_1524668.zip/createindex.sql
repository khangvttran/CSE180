-- Khang Tran
-- khvitran
-- CSE180
-- Lab3
-- createindex.sql

CREATE INDEX LookUpShowings ON Showings(showingDate, startTime);
