# CSE 180 - Lab4

## Table of Contents
1. RunMovieTheaterApplication.java
	* Contains starter code to run functions.
1. MovieTheaterApplication.java
	* getShowingsCount()
	* updateMovieName()
	* reduceSomeTicketPrices() calls reduceSomeTicketPricesFunction.pgsql
1. reduceSomeTicketPricesFunction.pgsql
    * Stored Function
1. createMovieTheaterViews.sql
    * Not required for the code to work properly.
    * Used to test answers.
    * '\i createMovieTheaterViews.sql' creates view showTickets.
